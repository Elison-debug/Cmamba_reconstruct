set(CMAKE_ASM_COMPILER "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin/aarch64-none-elf-gcc.exe")
set(CMAKE_ASM_COMPILER_ARG1 "")
set(CMAKE_AR "aarch64-none-elf-ar")
set(CMAKE_ASM_COMPILER_AR "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin/aarch64-none-elf-gcc-ar.exe")
set(CMAKE_RANLIB "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin/aarch64-none-elf-ranlib.exe")
set(CMAKE_ASM_COMPILER_RANLIB "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin/aarch64-none-elf-gcc-ranlib.exe")
set(CMAKE_LINKER "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin/aarch64-none-elf-ld.exe")
set(CMAKE_MT "")
set(CMAKE_ASM_COMPILER_LOADED 1)
set(CMAKE_ASM_COMPILER_ID "GNU")
set(CMAKE_ASM_COMPILER_VERSION "")
set(CMAKE_ASM_COMPILER_ENV_VAR "ASM")


set(CMAKE_ASM_COMPILER_SYSROOT "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin//../aarch64-xilinx-elf/usr")
set(CMAKE_COMPILER_SYSROOT "E:/Xilinx/Vitis/2024.1/gnu/aarch64/nt/aarch64-none/bin//../aarch64-xilinx-elf/usr")

set(CMAKE_ASM_IGNORE_EXTENSIONS h;H;o;O;obj;OBJ;def;DEF;rc;RC)
set(CMAKE_ASM_LINKER_PREFERENCE 0)


